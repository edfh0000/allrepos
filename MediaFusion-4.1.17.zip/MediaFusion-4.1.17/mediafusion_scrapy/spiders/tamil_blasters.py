from mediafusion_scrapy.spiders.common import CommonTamilSpider


class TamilBlastersSpider(CommonTamilSpider):
    name = "tamil_blasters"
    source = "TamilBlasters"
