from mediafusion_scrapy.spiders.common import CommonTamilSpider


class TamilMVSpider(CommonTamilSpider):
    name = "tamilmv"
    source = "TamilMV"
